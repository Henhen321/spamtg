global.resposta = {
    feito: 'Feito!',
    admin: 'Este recurso só pode ser utilizado por administradores',
    botAdmin: 'Este recurso só pode ser utilizado quando o bot é um administrador do grupo',
    dono: 'Este recurso só pode ser utilizado pelo proprietario',
    grupo: 'Este recurso é apenas para grupos',
    privado: 'Este recurso é apenas para chats privados',
    aguarde: 'Aguarde uns minutos...',
    error: 'Erro!',
}